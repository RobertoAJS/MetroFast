package com.example.metrofast.servicesimplements;

import com.example.metrofast.entities.ViajeProgramado;
import com.example.metrofast.repositories.IViajeProgramadoRepository;
import com.example.metrofast.servicesinterfaces.IViajeProgramadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ViajeProgramadoServiceImplement implements IViajeProgramadoService {
    @Autowired
    private IViajeProgramadoRepository vR;


    @Override
    public void insert(ViajeProgramado viajeprogramado) { vR.save(viajeprogramado); }


    @Override
    public List<ViajeProgramado> list() {
        return vR.findAll();
    }

    @Override
    public void delete(int tripid) {
        vR.deleteById(tripid);

    }

    @Override
    public void update(ViajeProgramado viajeprogramado) {
        vR.save(viajeprogramado);

    }
}
