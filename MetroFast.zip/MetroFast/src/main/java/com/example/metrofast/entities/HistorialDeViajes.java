package com.example.metrofast.entities;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name ="HistorialDeViajes")
public class HistorialDeViajes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int historyid;
    @Column(name = "traveldate", nullable = false)
    private LocalDate traveldate;
    @Column(name = "totalprice", nullable = false, length = 40)
    private int totalprice;
    @Column(name = "transportmode", nullable = false, length = 40)
    private int transportmode;

    @ManyToOne
    @JoinColumn(name = "tripid")
    private ViajeProgramado tripid;




    public HistorialDeViajes() {
    }
}
