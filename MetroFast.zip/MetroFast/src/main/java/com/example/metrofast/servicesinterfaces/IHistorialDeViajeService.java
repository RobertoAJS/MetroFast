package com.example.metrofast.servicesinterfaces;

import com.example.metrofast.entities.HistorialDeViajes;

import java.util.List;

public interface IHistorialDeViajeService {
    public void insert(HistorialDeViajes historialdeviajes);
    public List<HistorialDeViajes> list();
    public void delete(int historyid);
    public void update(HistorialDeViajes historialdeviajes);
}
