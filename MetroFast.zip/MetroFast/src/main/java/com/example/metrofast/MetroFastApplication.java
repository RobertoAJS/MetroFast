package com.example.metrofast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetroFastApplication {

    public static void main(String[] args) {
        SpringApplication.run(MetroFastApplication.class, args);
    }

}
