package com.example.metrofast.controllers;

import com.example.metrofast.dtos.HistorialDeViajesDTO;
import com.example.metrofast.dtos.ViajeProgramadoDTO;
import com.example.metrofast.entities.HistorialDeViajes;
import com.example.metrofast.entities.ViajeProgramado;
import com.example.metrofast.servicesinterfaces.IViajeProgramadoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/viajesprogramados")
public class ViajeProgramadoController {
    @Autowired
    private IViajeProgramadoService vS;

    @PostMapping("/registrar")
    public void registrar(@RequestBody ViajeProgramadoDTO dto) {
        ModelMapper m = new ModelMapper();
        ViajeProgramado a = m.map(dto, ViajeProgramado.class);
        vS.insert(a);
    }

    @GetMapping("/listas")
    public List<ViajeProgramadoDTO> listar() {
        return vS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, ViajeProgramadoDTO.class);
        }).collect(Collectors.toList());
    }

    @PutMapping("/modificar")
    public void modificar(@RequestBody ViajeProgramadoDTO dto) {
        ModelMapper m = new ModelMapper();
        ViajeProgramado s = m.map(dto, ViajeProgramado.class);
        vS.update(s);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id") Integer id) {
        vS.delete(id);
    }

}
