package com.example.metrofast.servicesimplements;

import com.example.metrofast.entities.HistorialDeViajes;
import com.example.metrofast.repositories.IHistorialDeViajesRepository;
import com.example.metrofast.servicesinterfaces.IHistorialDeViajeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistorialDeViajesServiceImplement implements IHistorialDeViajeService {
    @Autowired
    private IHistorialDeViajesRepository hR;


    @Override
    public void insert(HistorialDeViajes historialdeviajes) {hR.save(historialdeviajes);}


    @Override
    public List<HistorialDeViajes> list() {
        return hR.findAll();
    }

    @Override
    public void delete(int historyid) {
        hR.deleteById(historyid);

    }

    @Override
    public void update(HistorialDeViajes historialdeviajes) {
        hR.save(historialdeviajes);

    }
}
