package pe.edu.upc.metrofast.ServiceInterface;

public interface IPreferenceServices {


}
