package pe.edu.upc.metrofast.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.metrofast.Repositories.IRolesRepository;
import pe.edu.upc.metrofast.ServiceInterface.IRolesServices;

@Service
public class RolesServiceImplement implements IRolesServices {
    @Autowired
    private IRolesRepository rS;
}
