package pe.edu.upc.metrofast.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upc.metrofast.Entity.Preferences;
import pe.edu.upc.metrofast.Entity.Users;

@Repository
public interface IPreferencesRepository extends JpaRepository<Preferences, Integer> {


}
