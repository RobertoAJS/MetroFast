package pe.edu.upc.metrofast.dtos;

public class PreferenceDTO {
}
