package pe.edu.upc.metrofast.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.metrofast.Entity.Users;
import pe.edu.upc.metrofast.Repositories.IUsersRepository;
import pe.edu.upc.metrofast.ServiceInterface.IUsersServices;

import java.util.List;

@Service
public class UserServiceImplement implements IUsersServices {
    @Autowired
    private IUsersRepository uS;

    @Override
    public void insert(Users users) {uS.save(users);}

    @Override
    public List<Users> list() {return uS.findAll();}

    @Override
    public void delete(int id) {uS.deleteById(id);}

    @Override
    public Users listarid(int userID) {
        return uS.findById(userID).orElse(new Users());}
}
