package pe.edu.upc.metrofast.ServiceInterface;
import pe.edu.upc.metrofast.Entity.Users;
import java.util.List;

public interface IUsersServices {

    public void insert (Users users);
    public List<Users> list();
    public void delete (int id);
    public Users listarid (int userID);

}
