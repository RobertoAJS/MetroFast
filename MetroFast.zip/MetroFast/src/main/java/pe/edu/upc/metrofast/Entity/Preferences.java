package pe.edu.upc.metrofast.Entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "Preferences")
public class Preferences {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Preferenceid;
    @Column(name = "UsuarioID", nullable = false)
    private int UsuarioID;
    @Column(name = "Bicicleta", nullable = false)
    private Boolean prefer_bike;
    @Column(name = "Combi", nullable = false)
    private Boolean prefer_combi;
    @Column(name = "Microbus", nullable = false)
    private Boolean prefer_microbus;
    @Column(name = "Corredor", nullable = false)
    private Boolean prefer_corredor;
    @Column(name = "Metropolitano", nullable = false)
    private Boolean prefer_metropolitano;
    @Column(name = "Taxi", nullable = false)
    private Boolean prefer_taxi;
    @Column(name = "Update", nullable = false)
    private LocalDate update_at;

    @ManyToOne
    @JoinColumn(name = "user_id",nullable = false)
    private Users users;

    public Preferences() {
    }

    public Preferences(int preferenceid, int usuarioID, Boolean prefer_bike, Boolean prefer_combi, Boolean prefer_microbus, Boolean prefer_corredor, Boolean prefer_metropolitano, Boolean prefer_taxi, LocalDate update_at, Users users) {
        Preferenceid = preferenceid;
        UsuarioID = usuarioID;
        this.prefer_bike = prefer_bike;
        this.prefer_combi = prefer_combi;
        this.prefer_microbus = prefer_microbus;
        this.prefer_corredor = prefer_corredor;
        this.prefer_metropolitano = prefer_metropolitano;
        this.prefer_taxi = prefer_taxi;
        this.update_at = update_at;
        this.users = users;
    }

    public int getPreferenceid() {
        return Preferenceid;
    }

    public void setPreferenceid(int preferenceid) {
        Preferenceid = preferenceid;
    }

    public int getUsuarioID() {
        return UsuarioID;
    }

    public void setUsuarioID(int usuarioID) {
        UsuarioID = usuarioID;
    }

    public Boolean getPrefer_bike() {
        return prefer_bike;
    }

    public void setPrefer_bike(Boolean prefer_bike) {
        this.prefer_bike = prefer_bike;
    }

    public Boolean getPrefer_combi() {
        return prefer_combi;
    }

    public void setPrefer_combi(Boolean prefer_combi) {
        this.prefer_combi = prefer_combi;
    }

    public Boolean getPrefer_microbus() {
        return prefer_microbus;
    }

    public void setPrefer_microbus(Boolean prefer_microbus) {
        this.prefer_microbus = prefer_microbus;
    }

    public Boolean getPrefer_corredor() {
        return prefer_corredor;
    }

    public void setPrefer_corredor(Boolean prefer_corredor) {
        this.prefer_corredor = prefer_corredor;
    }

    public Boolean getPrefer_metropolitano() {
        return prefer_metropolitano;
    }

    public void setPrefer_metropolitano(Boolean prefer_metropolitano) {
        this.prefer_metropolitano = prefer_metropolitano;
    }

    public Boolean getPrefer_taxi() {
        return prefer_taxi;
    }

    public void setPrefer_taxi(Boolean prefer_taxi) {
        this.prefer_taxi = prefer_taxi;
    }

    public LocalDate getUpdate_at() {
        return update_at;
    }

    public void setUpdate_at(LocalDate update_at) {
        this.update_at = update_at;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }
}
