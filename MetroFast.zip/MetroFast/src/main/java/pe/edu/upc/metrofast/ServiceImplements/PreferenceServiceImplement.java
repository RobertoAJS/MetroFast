package pe.edu.upc.metrofast.ServiceImplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.metrofast.Repositories.IPreferencesRepository;
import pe.edu.upc.metrofast.ServiceInterface.IPreferenceServices;

@Service
public class PreferenceServiceImplement implements IPreferenceServices {
    @Autowired
    private IPreferencesRepository pS;
}
