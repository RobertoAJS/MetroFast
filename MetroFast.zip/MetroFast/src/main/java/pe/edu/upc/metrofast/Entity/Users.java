package pe.edu.upc.metrofast.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name="Users")
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int UserID;
    @Column(name = "username", nullable = false, length = 25)
    private String username;
    @Column(name = "email", nullable = false, length = 25)
    private String email;
    @Column(name = "password", nullable = false, length = 25)
    private String password;
    @Column(name = "phonenumber", nullable = false, length = 25)
    private int phonenumber;
    @Column(name = "createat", nullable = false)
    private LocalDate createat;
    @Column(name = "updateat", nullable = false)
    private LocalDate updateat;
    @Column(name = "deletedat", nullable = false)
    private int deletedat;


    @OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    @JoinColumn(name="user_id")
    @JsonIgnore
    private List<Roles> roles;


    public Users() {
    }

    public Users(int userID, String username, String email, String password, int phonenumber, LocalDate createat, LocalDate updateat, int deletedat, List<Roles> roles) {
        UserID = userID;
        this.username = username;
        this.email = email;
        this.password = password;
        this.phonenumber = phonenumber;
        this.createat = createat;
        this.updateat = updateat;
        this.deletedat = deletedat;
        this.roles = roles;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(int phonenumber) {
        this.phonenumber = phonenumber;
    }

    public LocalDate getCreateat() {
        return createat;
    }

    public void setCreateat(LocalDate createat) {
        this.createat = createat;
    }

    public LocalDate getUpdateat() {
        return updateat;
    }

    public void setUpdateat(LocalDate updateat) {
        this.updateat = updateat;
    }

    public int getDeletedat() {
        return deletedat;
    }

    public void setDeletedat(int deletedat) {
        this.deletedat = deletedat;
    }

    public List<Roles> getRoles() {
        return roles;
    }

    public void setRoles(List<Roles> roles) {
        this.roles = roles;
    }
}
