package pe.edu.upc.metrofast.Entity;

import jakarta.persistence.*;

@Entity
@Table(name="Roles")
public class Roles {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRol;
    @Column (name = "Rol", nullable = false)
    private int rol;

    @ManyToOne
    @JoinColumn(name = "user_id",nullable = false)
    private Users users;

    public Roles() {
    }

    public Roles(int idRol, int rol, Users users) {
        this.idRol = idRol;
        this.rol = rol;
        this.users = users;
    }

    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public int getRol() {
        return rol;
    }

    public void setRol(int rol) {
        this.rol = rol;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }
}
