package pe.edu.upc.metrofast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetroFastApplicationTests {

    @Test
    void contextLoads() {
    }

}
