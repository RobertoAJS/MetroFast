package pe.edu.upc.metrofast.entities;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name ="ViajeProgramado")
public class ViajeProgramado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tripid;
    @Column(name = "tripdate", nullable = false)
    private LocalDate tripdate;
    @Column(name = "totalprice", nullable = false, length = 40)
    private int totalprice;

    @ManyToOne
    @JoinColumn(name = "userid")
    private Usuario userid;

    @ManyToOne
    @JoinColumn(name = "lineid")
    private Linea lineid;


    public ViajeProgramado() {
    }
}
